# Calculadora de Volume de uma Caixa Retangular

comprimento = 12
largura = 14
altura = 20

volume = comprimento * largura * altura

print("Dimensões da caixa:")
print("Comprimento:", comprimento, "cm")
print("Largura:", largura, "cm")
print("Altura:", altura, "cm")
print("Volume =", volume, "cm³")
