# Programa de Saudação
# Exemplo simples de saída em Python

print("Hello, world!")
