# Calculadora de DIFERENCA = (A * B - C * D)

# Exemplo de entrada
A = 5
B = 6
C = 7
D = 8

DIFERENCA = (A * B - C * D)

print("Valores informados: A =", A, "B =", B, "C =", C, "D =", D)
print("DIFERENCA =", DIFERENCA)
