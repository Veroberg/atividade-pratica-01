# Calculadora de Soma

numero1 = 12
numero2 = 14
soma = numero1 + numero2

print("Número 1:", numero1)
print("Número 2:", numero2)
print("Soma =", soma)
